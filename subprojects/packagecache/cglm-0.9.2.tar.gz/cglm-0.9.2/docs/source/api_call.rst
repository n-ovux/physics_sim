Call API
================================

Call API is pre-built API for making calls from library. It is built on top of the array api. **glmc_** is the namespace for the call api. 
**c** stands for call. 

You need to built cglm to use call api. See build instructions (:doc:`build`) for more details.

The functions except namespace **glmc_** are same as inline api. See ( :doc:`api_inline_array` ) for more details.

📌 In the future we can define option to forward inline functions or struct api to call api.